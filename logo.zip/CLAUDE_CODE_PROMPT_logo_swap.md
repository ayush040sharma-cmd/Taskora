# Taskora — Logo & Favicon Swap

## Assets (already placed in repo — do this first)

Copy these files (provided alongside this prompt) into the frontend project:

```
frontend/src/assets/logo-full-lockup.png     ← icon + "TASKORA" wordmark, transparent bg (use in navbar/sidebar header, auth pages)
frontend/src/assets/logo-icon-mark.png       ← icon only, no text, transparent bg (use in collapsed sidebar, loading spinner, mobile header)
frontend/public/favicon.ico                  ← multi-size .ico (16/32/48)
frontend/public/favicon-16.png
frontend/public/favicon-32.png
frontend/public/favicon-48.png
frontend/public/favicon-180.png              ← apple-touch-icon
frontend/public/favicon-192.png              ← PWA / manifest icon
frontend/public/favicon-512.png              ← PWA / manifest icon
```

---

## STEP 1 — DIAGNOSE FIRST (do not skip)

Before changing anything, search the frontend codebase and report back with file:line references for every place the OLD logo, wordmark, or favicon currently appears. Specifically find:

1. All `<link rel="icon">`, `<link rel="apple-touch-icon">`, and any favicon references in `index.html`
2. Any `manifest.json` / `site.webmanifest` icon entries
3. Every component that renders a logo image or logo text (navbar, sidebar, auth/login page, loading screen, error/404 page, email templates if any)
4. Any hardcoded logo file paths or imports (`import logo from ...`)
5. Any place "Taskora" is rendered as styled text standing in for a logo (may need to stay as-is if it's brand wordmark typography, not a raster logo)

For each, report: file path, line number, what it currently renders, and a complexity rating (S/M/L) for swapping it.

**Do not write any code in this step. Wait for me to review the diagnosis before proceeding to Step 2.**

---

## STEP 2 — SCOPED FIX (only after diagnosis is approved)

Once I confirm the diagnosis:

1. Replace favicon references in `index.html` with the new files:
   ```html
   <link rel="icon" href="/favicon.ico" sizes="any">
   <link rel="icon" href="/favicon-32.png" type="image/png" sizes="32x32">
   <link rel="icon" href="/favicon-16.png" type="image/png" sizes="16x16">
   <link rel="apple-touch-icon" href="/favicon-180.png">
   ```
2. Update `manifest.json` / `site.webmanifest` icon entries to `favicon-192.png` and `favicon-512.png`.
3. Replace the navbar/sidebar logo render with `logo-full-lockup.png` (expanded state) and `logo-icon-mark.png` (collapsed sidebar state), preserving existing layout, sizing, and click-to-home behavior — do not change spacing, alignment, or container styles beyond what's needed to fit the new asset.
4. Replace any auth page / loading screen logo the same way.
5. Do NOT touch unrelated components, styles, or logic.

## Acceptance Checklist

- [ ] Favicon shows correctly in browser tab (light and dark browser chrome)
- [ ] Apple touch icon works when added to iOS home screen (or at least reference is correct)
- [ ] Navbar logo renders at correct size, no layout shift or squish
- [ ] Collapsed sidebar shows icon-only mark correctly
- [ ] No console errors for missing assets (404s)
- [ ] No existing tests broken
- [ ] Old logo file(s), if any, removed or left in place per your call — confirm before deleting anything
- [ ] Diffs shown before commit

Show diffs for review before finalizing.
